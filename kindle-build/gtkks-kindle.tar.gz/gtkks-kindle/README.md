# GTKKS for Kindle

This is the GTKKS application for Kindle.

To run the application, execute the gtkks.sh script.
